using UnityEngine;
public abstract class BasisContentBase : BasisNetworkContentBase
{
    [SerializeField]
    public BasisBundleDescription BasisBundleDescription;
}
