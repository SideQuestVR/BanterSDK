using UnityEngine.Serialization;

[System.Serializable]
public class BasisStoredEncryptedBundle
{
    [FormerlySerializedAs("LocalConnectorPath")]
    public string DownloadedBeeFileLocation;
}
