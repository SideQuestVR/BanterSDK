using UnityEngine.Serialization;

[System.Serializable]
public class BasisRemoteEncyptedBundle
{
    [FormerlySerializedAs("CombinedURL")]
    public string RemoteBeeFileLocation;
}
