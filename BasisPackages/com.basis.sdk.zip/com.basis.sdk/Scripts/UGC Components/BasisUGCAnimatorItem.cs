using UnityEngine;
[System.Serializable]
public struct BasisUGCAnimatorItem
{
    public BasisUGCMenuDescription Description;
    public string AnimatorEventName;
    public Animator AnimatorEvent;
}
