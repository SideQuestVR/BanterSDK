using UnityEngine;
namespace Basis.Scripts.UGC.BlendShapes
{
    public class BasisUGCExpressions : MonoBehaviour
    {
        public BasisUGCMenuDescription[] MenuItems;
    }
}
