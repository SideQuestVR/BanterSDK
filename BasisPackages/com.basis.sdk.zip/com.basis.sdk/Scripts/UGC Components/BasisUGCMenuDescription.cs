using UnityEngine;
[System.Serializable]
public struct BasisUGCMenuDescription
{
    public string MenuName;
    public Sprite Sprite;
}
