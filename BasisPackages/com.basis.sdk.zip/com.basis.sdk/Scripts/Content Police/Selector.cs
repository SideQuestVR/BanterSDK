﻿public partial class BundledContentHolder
{
    public enum Selector
    {
        Avatar,
        System,
        Prop
    }
}
