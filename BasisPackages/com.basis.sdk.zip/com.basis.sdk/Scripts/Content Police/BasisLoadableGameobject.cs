using UnityEngine;

public class BasisLoadableGameobject
{
    public GameObject InSceneItem;
}

