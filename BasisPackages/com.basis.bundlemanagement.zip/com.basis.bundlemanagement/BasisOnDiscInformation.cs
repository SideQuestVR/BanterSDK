public class BasisOnDiscInformation
{
    public BasisRemoteEncyptedBundle StoredRemote = new BasisRemoteEncyptedBundle();//where we got meta file from
    public BasisStoredEncryptedBundle StoredLocal = new BasisStoredEncryptedBundle();//where we got bundle file from
    public string UniqueVersion;
}
